package lab;


import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class Lab {
	
	static Date today=new Date();
	 
	public static int fahrenietToCentigrade(int fahreniet)
	{
		return (fahreniet-32) * 5 /9;
	}
	
	public static int CentigradeToFahreniet(int centigrade)
	{
		return centigrade* 9 /5 +32;
	}
	
	public static String removeSignOfExclaimation(String in)
	{
		if(in==null || in.length()==0)
		{
			return in;
		}
		return in.replaceAll("!", "");
	}
	
	public  static int getCurrentDate()
	{
		LocalDate localDate=today.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return localDate.getDayOfMonth();
	}
	
	public static int getCurrentMonth()
	{
		LocalDate localDate=today.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return localDate.getMonthValue();
	}
	
	public static int getCurrentYear()
	{		
		LocalDate localDate=today.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return localDate.getYear();
	}
	

}
