package lab;


public class LabTest {
	public static void main(String []args)
	{
		Lab lab=new Lab();
		System.out.println("Value of 212 fahreniet in centigrade is: "+lab.fahrenietToCentigrade(212));
		
		System.out.println("Value of 100 Centigrade in fahreniet is: "+lab.CentigradeToFahreniet(100));
		;
		System.out.println(lab.removeSignOfExclaimation("Hurrah!We won the match"));
		
		System.out.println("Curren Date: "+lab.getCurrentDate());
		
		System.out.println("Curren Month: "+lab.getCurrentMonth());
		
		System.out.println("Curren year: "+lab.getCurrentYear());
		
	}

}

